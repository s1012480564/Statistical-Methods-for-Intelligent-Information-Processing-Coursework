import torch
import torch.nn as nn
import torch.nn.functional as F

class LogisticRegression:
    def __init__(self, input_dim, iters=500, lr=0.01):
        self.w = nn.Parameter(torch.randn(input_dim))
        self.iters = iters
        self.lr = lr
    
    def _zero_grad(self):
        if self.w.grad is not None:
            self.w.grad.data.zero_()
    
    def _update_weights(self):
        # 梯度下降更新权重
        self.w.data -= self.lr * self.w.grad.data
        
    def fit(self, X, y):
        for i in range(self.iters):
            pred = torch.sigmoid(torch.matmul(X, self.w))
            loss = F.binary_cross_entropy(pred, y)
            self._zero_grad()
            loss.backward()
            self._update_weights()
    
    def predict(self, X):
        with torch.no_grad():
            return torch.sigmoid(torch.matmul(X, self.w))


class RidgeRegression:
    def __init__(self, lambd=0.1):
        self.lambd = lambd
        
    def fit(self, X, y):
        XtX = torch.matmul(X.T, X)
        Xy = torch.matmul(X.T, y)
        XtX[np.diag_indices_from(XtX)] += self.lambd
        
        self.w = torch.linalg.solve(XtX, Xy)
        self.b = (y - torch.matmul(X, self.w)).mean()
    
    def predict(self, X):
        return torch.matmul(X, self.w) + self.b