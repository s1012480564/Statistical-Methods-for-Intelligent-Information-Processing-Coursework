import torch.nn as nn
import torch


class SparseEmbedding(nn.Module):
    def __init__(self, keymap_size_list, emb_dim):
        super(SparseEmbedding, self).__init__()
        self.keymap_size_list = keymap_size_list
        self.embeddings = nn.ModuleList(
            [nn.Embedding(i, emb_dim) for i in keymap_size_list]
        )
        self.num_features = len(keymap_size_list)

    def forward(self, x):
        output = []
        for i in range(self.num_features):
            emb_vec = self.embeddings[i](x[:, i])
            output.append(emb_vec)
        output = torch.cat(output, dim=1)
        return output


class WideDeepModel(nn.Module):
    def __init__(self,
                 num_sparse_feature,
                 num_dense_feature,
                 keymap_size_list,
                 emb_dim=8,
                 hidden_units=[100, 100]):
        super(WideDeepModel, self).__init__()
        self.num_sparse_feature = num_sparse_feature
        self.num_dense_feature = num_dense_feature
        self.sparse_embedding = SparseEmbedding(
            keymap_size_list, emb_dim
        )
        self.dense_linear = nn.Linear(num_dense_feature, 1)
        input_dim = int(self.num_sparse_feature * emb_dim)
        dnn_list = []
        for h in hidden_units:
            dnn_list.append(nn.Linear(input_dim, h))
            dnn_list.append(nn.ReLU())
            input_dim = h
        dnn_list.append(nn.Linear(input_dim, 1))
        self.sparse_dnn = nn.Sequential(*dnn_list)

    def forward(self, sparse_input, dense_input):
        sparse_embedding = self.sparse_embedding(sparse_input)
        sparse_logit = self.sparse_dnn(sparse_embedding)
        dense_logit = self.dense_linear(dense_input)
        logit = sparse_logit + dense_logit
        return torch.sigmoid(logit)

