import torch


class PCA:
    def __init__(self, contamination):
        self.contamination = contamination
    
    def fit(self, data):
        self.mean = data.mean(dim=0, keepdims=True)
        data = data - self.mean
        N = len(data)
        covariance = 1/N * data.T.mm(data)
        self.eigval, self.eigvec = torch.linalg.eigh(covariance)
        dist = torch.cdist(data, self.eigvec)
        score = dist / self.eigval[None, :]
        score = -score.sum(dim=1)
        self.threshold = torch.quantile(score, self.contamination)
    
    def predict(self, data):
        data = data - self.mean
        dist = torch.cdist(data, self.eigvec)
        score = dist / self.eigval[None, :]
        score = -score.sum(dim=1)
        pred = (score > self.threshold).long()
        return score, pred

class Mahalanobis():
    def __init__(self, contamination):
        self.contamination = contamination
    
    def fit(self, data):
        self.mean = data.mean(dim=0, keepdims=True)
        data = data - self.mean
        N = len(data)
        covariance = 1/N * data.T.mm(data)
        self.precision = torch.linalg.pinv(covariance, hermitian=True)
        score = -torch.sqrt((data.mm(self.precision) * data).sum(dim=1))
        self.threshold = torch.quantile(score, self.contamination)
    
    def predict(self, data):
        data = data - self.mean
        score = -torch.sqrt((data.mm(self.precision) * data).sum(dim=1))
        pred = (score > self.threshold).long()
        return score, pred

class CBLOF():
    def __init__(self, contamination, 
             n_clusters=8, iters=100,
             alpha=0.9, beta=8):
        self.contamination = contamination
        self.n_clusters = n_clusters
        self.alpha = alpha
        self.beta = beta
        self.iters = iters
    
    def _kmeans(self, data):
        N, D = data.shape
        centers = data[:self.n_clusters].clone()
        for i in range(self.iters):
            distances = (torch.cdist(data, centers))**2
            assign_idx = distances.argmin(dim=1, keepdims=True)
            centers.zero_()
            centers = torch.scatter_add(centers, 0, assign_idx.repeat(1, D), data)
            counts = torch.zeros(self.n_clusters, 1)
            counts = torch.scatter_add(counts, 0, assign_idx, torch.ones(N, 1))
            centers = centers / (counts + 1e-10)
        distances = (torch.cdist(data, centers))**2
        assign_idx = distances.argmin(dim=1, keepdims=True)
        return centers, assign_idx
    
    def fit(self, data):
        self.centers, labels = self._kmeans(data)
        
        self.cluster_sizes = torch.bincount(labels.squeeze())
        total_num = self.cluster_sizes.sum()
        sorted_cluster_sizes, sorted_idx = torch.sort(self.cluster_sizes, descending=True)
        
        alpha_list = torch.cumsum(sorted_cluster_sizes, dim=0) / total_num
        beta_list = sorted_cluster_sizes[:-1] / sorted_cluster_sizes[1:]
        separate_list = (alpha_list[:-1]>=self.alpha) & (beta_list>=self.beta)
        
        if len(torch.where(separate_list==True)[0]) > 0:
            separate_idx = torch.where(separate_list==True)[0][0]
        else:
            separate_idx = torch.where(alpha_list>=self.alpha)[0][0]
        
        self.large_centers = self.centers[sorted_idx[:separate_idx+1]]
        
        score = -torch.cdist(data, self.large_centers).min(dim=1)[0]
        self.threshold = torch.quantile(score, self.contamination)
     
    def predict(self, data):
        score = -torch.cdist(data, self.large_centers).min(dim=1)[0]
        pred = (score > self.threshold).long()
        return score, pred